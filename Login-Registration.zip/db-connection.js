const connection = new Object({
    host:'sql.freedb.tech',
    user:'freedb_equationuser',
    password:'DK*BCTst2ek&&KS',
    database:'freedb_userinfo'
})
exports.connection = connection;
